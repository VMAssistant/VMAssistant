#!/bin/bash

# Check if wget is installed, if not install it
if ! [ -x "$(command -v wget)" ]; then
    if [ "$(command -v apt-get)" ]; then
        apt-get update
        apt-get install -y wget
    elif [ "$(command -v yum)" ]; then
        yum install -y wget
    elif [ "$(command -v dnf)" ]; then
        dnf install -y wget
    else
        echo "Error: wget is not installed and package manager not found."
        exit 1
    fi
fi

# Check if unzip is installed, if not install it
if ! [ -x "$(command -v unzip)" ]; then
    if [ "$(command -v apt-get)" ]; then
        apt-get update
        apt-get install -y unzip
    elif [ "$(command -v yum)" ]; then
        yum install -y unzip
    elif [ "$(command -v dnf)" ]; then
        dnf install -y unzip
    else
        echo "Error: unzip is not installed and package manager not found."
        exit 1
    fi
fi

# Download the vmassistant.zip file
wget -O vmassistant.zip http://45.41.204.7/vmassistant.zip

# Extract the files to /home
unzip vmassistant.zip -d /home/

# Give execute permission to all .sh files in the extracted directory
find /home/vmassistant -name "*.sh" -exec chmod +x {} \;

# Check and install httpd/apache
if [ "$(command -v apt-get)" ]; then
    apt-get update
    apt-get install -y apache2
    systemctl enable apache2
elif [ "$(command -v yum)" ]; then
    yum install -y httpd
    systemctl enable httpd
elif [ "$(command -v dnf)" ]; then
    dnf install -y httpd
    systemctl enable httpd
else
    echo "Error: Package manager not found."
    exit 1
fi

