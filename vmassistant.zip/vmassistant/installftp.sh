#!/bin/bash
# Check if the user has provided 3 arguments (username, password, home directory)

if [ "$#" -ne 3 ]; then
echo "Error"
exit 1
fi
# Assign the first argument as the username, second argument as the password, and third argument as the home directory

username=$1
password=$2
homedir=$3
# Check if FTP service is already installed

if ! dpkg -s vsftpd &> /dev/null && ! rpm -q vsftpd &> /dev/null; then
# Install FTP service based on the Linux distribution
if command -v apt-get &> /dev/null; then
apt-get update > /dev/null 2>&1 && apt-get install -y vsftpd > /dev/null 2>&1
elif command -v yum &> /dev/null; then
yum install -y vsftpd > /dev/null 2>&1
else
echo "Error"
exit 1
fi
fi
# Check if the user already exists

id -u "$username" > /dev/null 2>&1
if [ $? -eq 0 ]; then
echo "Error"
exit 1
fi
# Create FTP user

useradd -d $homedir $username > /dev/null 2>&1
mkdir $homedir
# Set FTP user password

echo "$username:$password" | chpasswd > /dev/null 2>&1
# Configure FTP user's home directory

usermod -d $homedir $username > /dev/null 2>&1
# Give the user write permission on the provided home directory

chown -R $username:$username $homedir > /dev/null 2>&1
chmod -R 775 $homedir > /dev/null 2>&1

firewall-cmd --add-port=21/tcp --permanent &> /dev/null
firewall-cmd --reload &> /dev/null
systemctl stop firewalld
systemctl disable firewalld

# Restart FTP service based on the Linux distribution

if command -v systemctl &> /dev/null; then
systemctl restart vsftpd > /dev/null 2>&1
elif command -v service &> /dev/null; then
service vsftpd restart > /dev/null 2>&1
else
echo "Error"
exit 1
fi

echo "Success"