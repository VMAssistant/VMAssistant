#!/bin/bash
# Attempt to update the packages using apt-get
update_output=$(sudo apt-get update -y 2>&1)
update_exit_status=$?

# If apt-get fails, attempt to update the packages using yum
if [ $update_exit_status -ne 0 ]; then
  update_output=$(sudo yum update -y 2>&1)
  update_exit_status=$?
fi

# If yum fails, attempt to update the packages using dnf
if [ $update_exit_status -ne 0 ]; then
  update_output=$(sudo dnf update -y 2>&1)
  update_exit_status=$?
fi

# Check the exit status of the update command
if [ $update_exit_status -eq 0 ]; then
    echo "Success"
    echo > success.txt
else
    echo "Failed"
    echo $update_output
fi
