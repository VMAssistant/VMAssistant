#!/bin/bash

# Create log file
LOG_FILE=/var/log/speedtest.log
touch $LOG_FILE

# Check if speedtest-cli is installed
if ! command -v speedtest-cli &> /dev/null
then
    # Install speedtest-cli
    if [[ -e /etc/redhat-release ]]; then
        sudo yum install epel-release -y > /dev/null
        sudo yum install speedtest-cli -y > /dev/null
    elif [[ -e /etc/lsb-release ]]; then
        sudo apt-get update > /dev/null
        sudo apt-get install speedtest-cli -y > /dev/null
    else
        echo "ERROR: Unable to determine operating system" | tee -a $LOG_FILE
        exit 1
    fi
fi

# Perform the speed test and extract the result link
output=$(speedtest-cli --share 2>&1)
result=$(echo "$output" | tail -n 1)

# Check if result URL was generated
if [ -z "$result" ]
then
    echo "ERROR: Failed to generate speed test result URL" | tee -a $LOG_FILE
    echo "speedtest-cli output:" | tee -a $LOG_FILE
    echo "$output" | tee -a $LOG_FILE
    exit 1
fi

# Output only the result link
echo $result | awk '{print $3}' | tee -a $LOG_FILE

