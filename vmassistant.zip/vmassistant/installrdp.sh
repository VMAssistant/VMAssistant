# Check if SELINUX is enabled
if sestatus | grep -q "enabled"; then
  sudo yum install -y xrdp-selinux
else
  sudo yum install -y xrdp
fi
sudo yum groupinstall -y "xfce"
sudo systemctl enable --now xrdp
sudo firewall-cmd --add-port=3389/tcp --permanent
sudo firewall-cmd --reload
sudo yum install -y xorgxrdp
service xrdp restart
sed -i '/^#\[Xorg\]/,/^#code/ s/^#//' /etc/xrdp/xrdp.ini
service xrdp restart
