#!/bin/bash

cd /home/

# Remove the vmassistant folder
if rm -rf vmassistant/; then
  echo "Success"
else
  echo "Error"
  exit 1
fi

cd /root

# Delete all files starting with "vmassistant"
if rm -f vmassistant*; then
  echo "Success"
else
  echo "Error"
  exit 1
fi
