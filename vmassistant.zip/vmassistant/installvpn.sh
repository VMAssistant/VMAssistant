#!/bin/bash
if [[ -z $1 ]]; then
        echo "Please provide the name of the client as an argument"
        exit 1
fi
export AUTO_INSTALL=y
export PORT_CHOICE=1
export DNS=9
export CLIENT=$1
firewall-cmd --add-port=80/tcp --permanent &> /dev/null
firewall-cmd --add-port=443/tcp --permanent &> /dev/null
firewall-cmd --reload &> /dev/null
./openvpn-install.sh