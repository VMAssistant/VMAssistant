#!/bin/bash

server_ip=$1

# Check if Apache is installed
if ! command -v apache2 > /dev/null; then
    echo "Apache is not installed. Script failed to execute."
    exit 1
fi

# Create the backup
tar -czvf server_backup.tar.gz /

# Generate the ISO file
genisoimage -o server_backup.iso server_backup.tar.gz

# Serve the ISO file via a web server
cp server_backup.iso /var/www/html/

# Provide a link for downloading
download_link="http://$server_ip/server_backup.iso"
echo $download_link

# Calculate the delay based on the file size
file_size=$(wc -c <"server_backup.iso")
# you can adjust the delay time as per your need
# assuming you need 1 sec delay for 1mb
delay=$((file_size / 1000000))

# wait three times the calculated delay before deleting the file
sleep $((3*$delay))

#Delete the file
rm /var/www/html/server_backup.iso
