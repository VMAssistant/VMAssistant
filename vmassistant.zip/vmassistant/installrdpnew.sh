if [ -f /etc/redhat-release ]; then
  # Check if SELINUX is enabled
  if sestatus | grep -q "enabled"; then
    if ! yum list installed xrdp-selinux &>/dev/null; then
      sudo yum install -y xrdp-selinux &>/dev/null;
      if [ $? -eq 0 ]; then
        echo "Success"
      else
        echo "Error 1"
        exit 1
      fi
    else
      echo "Exists"
    fi
  else
    if ! yum list installed xrdp &>/dev/null; then
      rpm -Uvh https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm &>/dev/null;
      sudo yum install -y xrdp &>/dev/null;
      if [ $? -eq 0 ]; then
        echo "Success"
      else
        echo "Error 2"
        exit 1
      fi
    else
      echo "Exists"
    fi
  fi

  if ! yum list installed xfce &>/dev/null; then
    sudo yum groupinstall -y "xfce" &>/dev/null;
    if [ $? -eq 0 ]; then
      echo "Success"
    else
      echo "Error 3"
      exit 1
    fi
  else
    echo "Exists"
  fi

  sudo systemctl enable --now xrdp &>/dev/null;
  if [ $? -eq 0 ]; then
    echo "Success"
  else
    echo "Error"
    exit 1
  fi

  sudo firewall-cmd --add-port=3389/tcp --permanent &>/dev/null;
  sudo firewall-cmd --reload &>/dev/null;

  if ! yum list installed xorgxrdp &>/dev/null; then
    sudo yum install -y xorgxrdp &>/dev/null;
    if [ $? -eq 0 ]; then
      echo "Success"
    else
      echo "Error"
      exit 1
    fi
  else
    echo "Exists"
  fi

  service xrdp restart &>/dev/null;
  if [ $? -eq 0 ]; then
    echo "Success"
  else
    echo "Error"
    exit 1
  fi

  sed -i '/^#\[Xorg\]/,/^#code/ s/^#//' /etc/xrdp/xrdp.ini
  if [ $? -eq 0 ]; then
    echo "Success"
  else
    echo "Error"
    exit 1
  fi
  echo "xfce4-session" > ~/.Xclients;
  chmod a+x ~/.Xclients;
  service xrdp restart &>/dev/null;
  if [ $? -eq 0 ]; then
    echo "Success"
  else
    echo "Error"
    exit 1
  fi
elif [ -f /etc/lsb-release ]; then
  if ! dpkg -s xrdp &>/dev/null; then
    sudo apt update -y &>/dev/null;
    if [ $? -eq 0 ]; then
      echo "Success"
    else
      echo "Error"
      exit 1
    fi
    sudo apt install -y xrdp &>/dev/null;
    if [ $? -eq 0 ]; then
      echo "Success"
    else
      echo "Error"
      exit 1
    fi
  else
    echo "Exists"
  fi
  if ! dpkg -s xfce4 &>/dev/null; then
    sudo DEBIAN_FRONTEND=noninteractive apt install -y xfce4
    if [ $? -eq 0 ]; then
      echo "Success"
    else
      echo "Error"
      exit 1
    fi
  else
    echo "Exists"
  fi
  if ! dpkg -s xfce4-terminal &>/dev/null; then
    sudo apt-get -y install xfce4-terminal tango-icon-theme &>/dev/null;
    if [ $? -eq 0 ]; then
      echo "Success"
    else
      echo "Error"
      exit 1
    fi
  else
    echo "Exists"
  fi
  echo xfce4-session >~/.xsession &>/dev/null;
  if [ $? -eq 0 ]; then
    echo "Success"
  else
    echo "Error"
    exit 1
  fi
  sudo service xrdp restart &>/dev/null;
  if [ $? -eq 0 ]; then
    echo "Success"
  else
    echo "Error"
    exit 1
  fi

  sudo ufw allow 3389/tcp &>/dev/null;
  echo xfce4-session > ~/.xsession;
else
  echo "Error: This script only runs on Ubuntu or Redhat based Linux distributions."
  exit 1
fi
